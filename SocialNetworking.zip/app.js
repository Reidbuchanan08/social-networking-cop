let startTime;
let timerInterval;
let logData = "";

// Called on index.html login page
function signIn() {
  const username = document.getElementById("username").value;
  if (!username) {
    alert("Please enter a username.");
    return;
  }

  startTime = new Date();
  logData = `User '${username}' signed in at: ${startTime.toLocaleString()}\n`;

  // Save start time and username in localStorage
  localStorage.setItem("startTime", startTime);
  localStorage.setItem("username", username);

  // Redirect to feed page
  window.location.href = "feed.html";
}

// Called on feed.html page load
function startFeedTimer() {
  const savedTime = localStorage.getItem("startTime");
  const username = localStorage.getItem("username");

  if (!savedTime || !username) {
    // No active session — redirect back to login
    window.location.href = "index.html";
    return;
  }

  startTime = new Date(savedTime);
  timerInterval = setInterval(() => checkScreenTime(username), 1000);
}

function checkScreenTime(username) {
  const now = new Date();
  const elapsedSeconds = Math.floor((now - startTime) / 1000);
  const minutes = Math.floor(elapsedSeconds / 60);
  const seconds = elapsedSeconds % 60;

  const screenTimeDisplay = document.getElementById("screenTime");
  if (screenTimeDisplay) {
    screenTimeDisplay.textContent = `Screen time: ${minutes}m ${seconds}s`;
  }

  if (elapsedSeconds >= 1200) { // 20 minutes = 1200 seconds
    clearInterval(timerInterval);

    const message = "You have exceeded your daily screentime. Go enjoy the day!";
    alert(message);

    logData += `Screen time reached: ${minutes}m ${seconds}s\n`;
    logData += `${message}\n`;

    downloadLog(logData, username);

    // Clear storage and redirect to login
    localStorage.clear();
    window.location.href = "index.html";
  }
}

function downloadLog(data, username) {
  const blob = new Blob([data], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${username}_session_log.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

function signOut() {
  if (confirm("Are you sure you want to sign out?")) {
    clearInterval(timerInterval);
    localStorage.clear();
    window.location.href = "index.html";
  }
}